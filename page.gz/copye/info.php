<?php
phpinfo();
$conn=mysqli_connect('localhost',"projecte","Projecte20-21","clients");
if ($conn){
echo "Conexio correcta";
}else{
echo "ERROR";
}
?>
