<!DOCTYPE html>
<html lang="ca">
	<?php require "../../resources/plants/contact.php" ?>
</html>
