<?php $about = "service"?> 
<!DOCTYPE html>
<html lang="ca">
<?php include '../../resources/plants/services.php' ?>
</html>
