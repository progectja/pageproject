<!DOCTYPE html>
<html lang="ca">
	<?php include '../resources/plants/home.php' ?>
</html>
