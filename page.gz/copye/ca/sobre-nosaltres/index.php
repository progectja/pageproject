<!DOCTYPE html>
<html lang="ca">
	<?php include "../../resources/plants/about.php"?>
</html>
