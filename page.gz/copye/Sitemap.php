<?php

	$saltoLinea = "\r\n";
	$url        = "<url>".$saltoLinea;
	$burl       = "</url>".$saltoLinea;
	$loc        = "<loc>";
	$bloc       = "</loc>".$saltoLinea;
	$img        = "<image:image>".$saltoLinea;
	$bimg       = "</image:image>".$saltoLinea;
	$imgloc     = "<image:loc>";
	$bimgloc    = "</image:loc>".$saltoLinea;
	$imgtitle   = "<image:title>";
	$bimgtitle  = "</image:title>".$saltoLinea;
	$fecha = new DateTime('NOW');
	$mod        = "<lastmod>".$fecha->format('Y-m-d')."</lastmod>".$saltoLinea; //2014-05-22T09:07:05+00:00 'Y-m-dTH:i:sP'
	$changefreq = "<changefreq>daily</changefreq>".$saltoLinea;
	$priority   = "<priority>0.90</priority>".$saltoLinea;
	$arxiu      = "sitemap.xml";
	$fitxer = fopen($arxiu,'w');
	$site = "<?xml version='1.0' encoding='utf-8'?>".$saltoLinea;
	$site.= "<urlset xmlns='http://www.sitemaps.org/schemas/sitemap/0.9' xmlns:image='https://www.google.com/schemas/sitemap-image/1.1'>".$saltoLinea;

//-------------------------------
$site.= $url;
$site.= $loc."http://nicoprj.hopto.org/index.html".$bloc;
$site.= $mod;
$site.= $changefreq;
$site.= $priority;
$site.= $burl;

 //--------------------------------
		//require_once('Config.php'); no funciona amb cron
	for ($i=0;$i<$nfilas;$i++)

	{

		$fila =mysql_fetch_array($filas);

		$site.= $url;

		$site.= $loc;

		$site.= "http://nicoprj.hopto.org/articulo.php?c=".$fila['id'];

		$site.= $bloc;

		$site.= $img;

			$site.= $imgloc;

			$site.= "http://www.domini.com/img/".$fila['imagen'];

			$site.= $bimgloc;

			$site.= $imgtitle;

			$site.= $fila['titulo'];

			$site.= $bimgtitle;

		$site.= $bimg;

		$site.= $mod;

		$site.= $changefreq;

		$site.= $priority;

		$site.= $burl;

	}

	$site.= $saltoLinea."</urlset>";

	fwrite($fitxer,$site);

	fclose($fitxer);

	echo "<script type='text/javascript'>alert('Arxiu XML generat.');window.close();</script>";
?>
