<?php
session_start();
?>
<html>
<head>
</head>
<body>
	<?php
	$con=mysqli_connect("localhost","projecte","Projecte20-21","clients") or die ("Error al conectar al servidor o a la DB.");
	//$sql="select * from clients where usuari='".$_REQUEST['usu']."'";echo $sql;
	$sql="select * from clients where usuari='".$_REQUEST['usu']."' and contrasenya = '".$_REQUEST['pass']."'";
	$consulta=mysqli_query($con,$sql);
	$nfilas=mysqli_num_rows($consulta);

	if ($nfilas>0){
		$_SESSION['valido']=1;
		$_SESSION['usuari']=$_REQUEST['usu'];
		header('Location: http://nicoprj.hopto.org/log/userses.php');
		//echo "usuario correcto"."<br>"."<br>";
		//echo "1. <a href='subearchivo1.php'>Subir archivo</a>"."<br>";
		//echo "2. <a href='verarchivo.php'>Ver archvos colagdos</a>"."<br>";
		//echo "2. <a href='verarchivo1.php'>Ver archvos colagdos aaaaa</a>"."<br>";
		//echo "3. <a href='descargararchivo.php'>Descarga archivos</a>"."<br>";
		//echo "4. <a href='modificaciones.php'>Modificaciones</a>"."<br>";
		//echo "5. <a href='fotos.php'>Colgar foto</a>"."<br>";
		//echo "5. <a href='logout.php'>Logout</a>"."<br>";
	} else {
	$_SESSION['valido']=0;
	echo "Usuario i/o contraseña invalido/a";
	mysqli_close($con);
	}
?>
</body>
</html>
