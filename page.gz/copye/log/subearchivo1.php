<?php
session_start();
if($_SESSION['valido']==0){
	echo "ERROR. No has iniciado sesión.";
	header('Location: http://nicoprj.hopto.org/log/log.php');
}
if (isset($_REQUEST['Enviar'])){
	$user=$_SESSION['usuari'];
	$dir_subida="/var/www/usuaris/".$user."/";
//	$dir_subida="/home/ubuntu/ficheros/".$user."/";
	$fichero_subido = $dir_subida.$_FILES['fichero_usuario']['name'];
//	if ($_FILES['fichero_usuario']['size'] > 8000000){
//		echo "El fichero es demasiado grande"
//	} else {
		if (move_uploaded_file($_FILES['fichero_usuario']['tmp_name'], $fichero_subido)) {
   			echo "El fichero es válido y se subió con éxito.\n";
		} else {
    			echo "¡Posible ataque de subida de ficheros!\n";

		}
//	}
}
?>

<form action="subearchivo1.php" method="post" enctype="multipart/form-data">
	<b>Subir un nuevo archivo:</b>
	<br>
	<input type="file" name="fichero_usuario">
	<br>
	<input type="submit" name="Enviar">
	<br>
</form>
