<?php
session_start();
?>
<html>
<head>

<title>login</title>
<meta name="description" content="login">

<link rel="canonical" href="http://nicoprj.hopto.org">
<link rel="icon" href="/resources/img/favicon.png" type="">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
html{
width:100%;
}
body{
  //width:100%;
  align-items:center;
  justify-content:center;
  //position:relative;
  text-align:center;

}
main{
  height:auto;
  width: 70%;
  //position:relative;
  //display:flex;
  aling-items:center;
  justify-content:center;
  text-align:center;
}
form {
  border: 3px solid #f1f1f1;
  width: auto;
  height:auto;

}

.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}
.imgcontainer img {
  width: 40%;
  height: auto;
  border-radius: 50%;
}

.datlog {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

.golog {
  background-color: #04AA6D;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}
/*.datlog {
  padding:15px 18px;
  border: 1px solid #000000;
  margin-top: 6px;
  margin-bottom: 16px;
  width:90%;
}
.golog{
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 90%;
}*/
.golog:hover {
  opacity: 0.8;
  //background-color: #45a049;
}

img{
margin: 8px;
}

</style>

</head>
<body>
<a href='http://nicoprj.hopto.org/'>home</a>


<main>
	<form action="comprovar.php" method="post">
		<div class="imgcontainer">
			<img src="img/uselog512.png" title="log" alt="log" width="225" height="225" ></img><br>
		</div>
		<div class="container">
			
			<input placeholder="user" type="text" name="usu" class="datlog"><br>
			
			<input placeholder="password" type="password" name="pass" class="datlog"><br>
			
			<input type="submit" name="loing" class="golog">
		</div>
	</form>
</main>
</body>
</html>
