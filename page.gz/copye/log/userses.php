<?php
session_start();
if($_SESSION['valido']==0){
        echo "ERROR. No has iniciado sesión.";
	header('Location: http://nicoprj.hopto.org/log/log.php');
}
?>


<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="css/ususes.css">
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
</head>
	<body>

		<header>

			<a href='?logout'>logout</a>
 			<?php if (isset($_GET['logout'])) {$_SESSION['valido']=0;}?>
		</header>
		<hr>

		<aside id="mySidenav">
			<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
			<a id='hola' href='?upload'value='' >Subir archivo</a><br>
			<a href='?viewfiles'>Ver archivos colagdos</a><br>
			<a href='?delfiles'>borrar archivos</a><br>
		</aside>

		<a style="font-size:30px;cursor:pointer;" onclick="openNav()" class="openbtn">&#9776; open</a>

		<main>
		<?php
			if (isset($_GET['upload'])) {include 'subearchivo1.php';}
			else if (isset($_GET['delfiles'])) {include 'eliminar.php';}
			else {include 'verarchivo1.php';}
			//if (isset($_GET['viewfiles'])) {include 'verarchivo1.php';}
			//include 'verarchivo1.php';
                ?>
		</main>

		<footer>
		</footer>

		<script>
			function openNav() {
				document.getElementById("mySidenav").style.width = "50%";
			}
			function closeNav() {
				document.getElementById("mySidenav").style.width = "0px";
			}
			$(window).on("resize", function (){
				window.location.reload();
			});
		</script>
	</body>
</html>

