<?php
session_start();
if($_SESSION['valido']==0){
        echo "ERROR. No has iniciado sesión.";
}
function listar_archivos($carpeta){
    if(is_dir($carpeta)){
        if($dir = opendir($carpeta)){
            while(($archivo = readdir($dir)) !== false){
                if($archivo != '.' && $archivo != '..' && $archivo != '.htaccess' && $archivo !='.bash_logout' && $archivo !='.profile' && $archivo != '.bashrc'){
                    echo '<li>'.$archivo.'</a></li>';
                //echo $archivo;
                }
            }
            closedir($dir);
        }
    }
}
//print_r($_SESSION);
$user=$_SESSION['usuari'];
echo listar_archivos('/var/www/usuaris/'.$user);
echo "--------------------------------------------------------------";
echo "<form action='userses.php' method='post'>";
$_REQUEST['archivo'];
echo "Que archivo desea eliminar ?<br>";
echo "<input type='text' name='archivo'>";
echo "<input type='submit' value='Eliminar' name='eliminar'>";
echo "</form>";
$archivo1=$_POST[archivo];
//echo "unlink('/home/ubuntu/ficheros/$archivo1')";
echo "unlink('/var/www/usuaris/'.$user.'/'.$archivo1)";
if (unlink("/var/www/usuaris/".$user."/".$archivo1)) {
	echo "El fichero se ha eliminado correctamente";
} else {
	echo "No se ha eliminado el fichero";
}

?>
