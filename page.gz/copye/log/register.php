<html>
<head>

</head>
<body>
<?php

   	if (isset($_REQUEST['alta'])){
	$con=mysqli_connect("localhost","projecte","Projecte20-21","clients") or die ("Error al conectar.");
	$sql="insert into clients (nom, cognoms, correu, edat, usuari, contrasenya) values ('".$_REQUEST['nom']."','".$_REQUEST['cog']."','".$_REQUEST['mail']."','".$_REQUEST['edat']."','".$_REQUEST['usu']."','".$_REQUEST['pass']."')";
	$consulta=mysqli_query($con,$sql);
	$sortida=shell_exec("sudo ./creausu.sh ".$_REQUEST['usu']);
	if ($consulta){  echo "ALTA REALIZADA"."<br>";
//	$usuari=$_REQUEST['usu'];
	echo "$sortida";}
//	echo "$usuari";}
	else echo "ALTA NO REALIZADA";
	} else {
	echo "<form action='register.php' method='post'>";
	echo "Usuari: <input type='text' name='usu'><br>";
	echo "Contrasenya: <input type='password' name='pass'><br>";
	echo "Nom: <input type='text' name='nom'><br>";
	echo "Cognom: <input type='text'name='cog'><br>";
	echo "Correu <input type='text' name='mail'><br>";
	echo "Edat: <input type='text' name='edat'><br>";
	echo "<input type='submit' value='Alta' name='alta'>";
	echo "</form>";
//	echo "$sortida";
	 }
?>
</body>
</html>
