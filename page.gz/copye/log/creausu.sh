#!/bin/bash
useradd -m -d /var/www/usuaris/$1 $1
echo "$1 creado"
