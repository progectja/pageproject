<?php
session_start();
if($_SESSION['valido']==0){
        echo "ERROR. No has iniciado sesión.";
        header('Location: http://nicoprj.hopto.org/log/log.php');
}
function listar_archivos($carpeta){
    if(is_dir($carpeta)){
        if($dir = opendir($carpeta)){
            while(($archivo = readdir($dir)) !== false){
                if($archivo != '.' && $archivo != '..' && $archivo != '.htaccess' && $archivo !='.bash_logout' && $archivo !='.profile' && $archivo != '.bashrc'){
                    echo '<li><a href="descargararchivo.php?file='.basename($archivo).'">'.$archivo.'</a></li>';
                //echo $archivo;
                }
            }
            closedir($dir);
        }
    }
}
//print_r($_SESSION);
$user=$_SESSION['usuari'];
echo listar_archivos('/var/www/usuaris/'.$user);
//$file = $_GET['file'];
//header("Content-disposition: attachment; filename=$file");
//header("Content-type: application/octet-stream");
//readfile($file);
?>
