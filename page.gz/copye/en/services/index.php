<!DOCTYPE html>
<html lang="en">
	<?php include "../../resources/plants/services.php";?>
</html>
