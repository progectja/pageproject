<!DOCTYPE html>
<html lang="en">
	<?php include "../../resources/plants/about.php";?>
</html>
