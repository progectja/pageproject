<!DOCTYPE html>
<html lang="en">
	<?php include "../resources/plants/home.php";?>
</html>
