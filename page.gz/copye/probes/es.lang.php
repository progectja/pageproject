<?php
define('_HELLO', 'hola');
define('_h1','pruebas funcionan');
?>
