<?php
   define('_HELLO', 'hola');
   define('_hl','probes ok');
?>
