<!DOCTYPE html>
<html lang="es">
	<?php include "../resources/plants/home.php";?>
</html>
