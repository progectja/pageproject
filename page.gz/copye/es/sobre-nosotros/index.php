<!DOCTYPE html>
<html lang="es">
	<?php include "../../resources/plants/about.php";?>
</html>
