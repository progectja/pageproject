define( 'SITEMAP_DIR', './' );
define( 'SITEMAP_DIR_URL', 'http://nicoprj.hopto.org/' );
define( 'RECURSIVE', true );
$filetypes = array( 'php', 'html', 'pdf' );
// The replace array, this works as file => replacement, so 'index.php' => '', would make the index.php be listed as just /
$replace = array( 'index.php' => '' );
$xsl = 'xml.xsl';
$chfreq = 'daily';
$prio = 1;
$ignore = array( 'config.php' );
