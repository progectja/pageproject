<?php
define('_lang','/en/');
//header
define('_regist','register');
define('_log','login');

define('_progect','project');

define('_home','home');
define('_services','services');
define('_contact','contact');
define('_about','about');

//home

//services
define('_plan1','basic plan');/*basic*/
define('_plan2','half year business plan');/*buines 6months*/
define('_plan3','year business plan');/*buines year*/
define('_price1','month');/*mensual*/
define('_price2','year');/*anual*/
define('_ofert1','free 1 month');/*un mes*/
define('_ofert2','free 3 months');/*trimestre*/
define('_storage','storage');
define('_trash1','trash service');/*normal trash*/
define('_trash2','unlimited trash service');/*unlimited trash*/
define('_autgest','multi-user space self-management');/*autogestió d'espai multiusuari*/

//contact
define('_name','name');
define('_surnames','surnames');
define('_mail','mail');
define('_subject','subject');
define('_coment','coment');
define('_send','send');
define('_reset','reset');

//about
define('_pr1name','About us?<br>');
define('_pr1info','In 2020, three undergraduate students in Computer Systems and Network Administration set out to open a Clouding service with the aim of doing their final degree work.');
define('_pr2name','What is our commitment?<br>');
define('_pr2info','Our commitment is to offer access to all your (name) information 24/7, 365 days a year.');
define('_pr3name','What is clouding?<br>');
define('_pr3info','Clouding or cloud service is a paradigm that allows computing services to be offered through a network, which is usually the internet.');
define('_pr4name','Our service.<br>');
define('_pr4info','We offer a clouding service that consists of hiring a part of the hard disk to be able to upload and download a file from wherever you want as long as you have internet.');

?>
