<?php
        $langs = array('/ca', '/es', '/en');
        $servicesloc = array('/serveis/', '/servicios/', '/services/');
        $contactloc = array('/contacte/', '/contacto/', '/contact/');
        $aboutloc = array('/sobre-nosaltres/', '/sobre-nosotros/', '/about/');

        $url='http://'.$_SERVER['HTTP_HOST'];
        $url2=str_replace($langs,'',$_SERVER['REQUEST_URI']);


        //if($url2=='//') {$dir_ca='';$dir_es=''; $dir_en='';}

        //---------------------
        //services
        if(in_array($url2,$servicesloc)) {
		$dir_ca='serveis/';
		$dir_es='servicios/';
		$dir_en='services/';
	}
        //---------------------
        //contact
        if(in_array($url2,$contactloc)) {
		$dir_ca='contacte/';
		$dir_es='contacto/';
		$dir_en='contact/';
	}
        //---------------------ç
        //about
        if(in_array($url2,$aboutloc)) {
		$dir_ca='sobre-nosaltres/';
		$dir_es='sobre-nosotros/';
		$dir_en='about/';
	}

        //--------------------
        //mount
        $lang_ca=$url.'/ca/'.$dir_ca;
        $lang_es=$url.'/es/'.$dir_es;
        $lang_en=$url.'/en/'.$dir_en;
?>


