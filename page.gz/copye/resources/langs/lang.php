<?php

//header
define('_regist','');
define('_log','');

define('_progect','');

define('_home','');
define('_services','');
define('_contact','');
define('_about','');

//home

//services
define('_plan1','');/*basic*/
define('_plan2','');/*buines 6months*/
define('_plan3','');/*buines year*/
define('_price1','');/*mensual*/
define('_price2','');/*anual*/
define('_ofert1','');/*un mes*/
define('_ofert2','');/*trimestre*/
define('_storage','');
define('_trash1','');/*normal trash*/
define('_trash2','');/*unlimited trash*/
define('_autgest','');/*autogestió d'espai multiusuari*/

//contact
define('_name','');
define('_surnames','');
define('_mail','');
define('_subject','');
define('_coment','');
define('_send','');
define('_reset','');

//about
define('_pr1name','');
define('_pr1info','');
define('_pr2name','');
define('_pr2info','');
define('_pr3name','');
define('_pr3info','');
define('_pr4name','');
define('_pr4info','');

?>
