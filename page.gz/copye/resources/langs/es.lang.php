<?php
define('_lang','/es/');
//header
define('_regist','registrarse');
define('_log','acceso');

define('_progect','proyecto');

define('_home','inicio');
define('_services','servicios');
define('_contact','contacto');
define('_about','sobre-nosotros');

//home

//services
define('_plan1','plan básico');/*basic*/
define('_plan2','plan empresarial de 6 meses');/*buines 6months*/
define('_plan3','plan empresarial anual');/*buines year*/
define('_price1','mes');/*mensual*/
define('_price2','año');/*anual*/
define('_ofert1','gratis 1 mes');/*un mes*/
define('_ofert2','gratis 3 meses');/*trimestre*/
define('_storage','almacenamiento');
define('_trash1','servicio de basura');/*normal trash*/
define('_trash2','servicio de basura ilimitado');/*unlimited trash*/
define('_autgest','autogestión de espacio multiusuario');/*autogestió d'espai multiusuari*/

//contact
define('_name','nombre');
define('_surnames','apellidos');
define('_mail','correo');
define('_subject','asunto');
define('_coment','comentarios');
define('_send','enviar');
define('_reset','reiniciar');

//about
define('_pr1name','Sobre nosotros?<br>');
define('_pr1info','En 2020 tres estudiantes de grado superior de Administración de Sistemas Informáticos y Redes se dispusieron a abrir un servicio de Clouding con el objetivo de hacer el trabajo de fin de grado.');
define('_pr2name','¿Cuál es nuestro compromiso?<br>');
define('_pr2info','Nuestro compromiso es ofrecer acceso a toda tu información de (nombre) las 24h/7 días a la semana durante los 365 días del año.');
define('_pr3name','Que es el clouding?<br>');
define('_pr3info','Clouding o servicio en la nube es un paradigma que permite ofrecer servicios de computación a través de una red, que usualmente es el internet.');
define('_pr4name','Nuestro servicio.<br>');
define('_pr4info','Nosotros ofrecemos un servicio de clouding que consiste en contratar una parte de disco duro para poder colgar y descargar un archivo desde donde quieras siempre que tengas internet.');

?>
