<?php
define('_lang','/ca/');
//header
define('_regist','registrar-se');
define('_log','iniciar Sessió');

define('_progect','projecte');

define('_home','inici');
define('_services','serveis');
define('_contact','contacte');
define('_about','sobre-nosaltres');

//home

//services
define('_plan1','pla bàsic');/*basic*/
define('_plan2','pla empresarial de mig any');/*buines 6months*/
define('_plan3','pla empresarial anual');/*buines year*/
define('_price1','mes');/*mensual*/
define('_price2','any');/*anual*/
define('_ofert1','1 mes gratis');/*un mes*/
define('_ofert2','3 mesos gratis');/*trimestre*/
define('_storage',"d'emmagatzematge");
define('_trash1',"servei d'escombraries");/*normal trash*/
define('_trash2',"servei d'escombraries il·limitat");/*unlimited trash*/
define('_autgest',"autogestió d'espai multiusuari");/*autogestió d'espai multiusuari*/

//contact
define('_name','nom');
define('_surnames','cognoms');
define('_mail','correu');
define('_subject','assumpte');
define('_coment','comentaris');
define('_send','enviar');
define('_reset','restableix');

//about
define('_pr1name','Sobre nosaltres?<br>');
define('_pr1info',"El 2020 tres estudiants de grau superior d'Administració de Sistemes Informàtics i Xarxes es van disposar a obrir un servei de Clouding amb l'objectiu de fer el treball de final de grau.");
define('_pr2name','Quin és el nostre compromís?<br>');
define('_pr2info',"El nostre compromís és oferir accés a tota la teva informació de 'nom' les 24h/7 dies a la setmana durant els 365 dies de l'any.");
define('_pr3name','Que es el clouding?<br>');
define('_pr3info',"Clouding o servei al núvol és un paradigme que permet oferir serveis de computació a través d'una xarxa, que usualment és l'internet.");
define('_pr4name','El nostre servei.<br>');
define('_pr4info',"El nostre servei.<br>Nosaltres oferim un servei de clouding que consisteix a contractar una part de discdur per poder penjar i descarregar un arxiu des d'on vulguis sempre que tinguis internet.");

?>
