<main>
	<!--<div id="marger"></div>-->
	<div class="form">
		<form name="proba">
			<input placeholder=<?php echo _name ?> type="text" class="basic-form con con1" required></input>
			<input placeholder=<?php echo _surnames ?> type="text" class="basic-form con con2" required></input>
			<br>
			<input placeholder=<?php echo _mail ?> type="text" class="basic-form con con1" required></input>
			<input placeholder=<?php echo _subject ?> type="text" class="basic-form con con2" required></input>
			<br>
			<textarea placeholder=<?php echo _coment ?> class="basic-form desc" required></textarea>
			<br>
			<input class="basic-form but" type="submit" value=<?php echo _send; ?>></input>
			<input class="basic-form but" type="reset" value=<?php echo _reset; ?>></input>

		</form>
	</div>

</main>
