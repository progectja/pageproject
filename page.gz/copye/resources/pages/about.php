<main>
<div class="main" id="allpr">
    <p class="infabout" id="pr1">
       	<?php
	echo _pr1name;
	echo _pr1info;
	?>
	<?php
	/* Sobre nosaltres? <br>
	El 2020 tres estudiants de grau superior d'Administració de Sistemes Informàtics
	i Xarxes es van disposar a obrir un servei de Clouding amb l'objectiu de fer el
	treball de final de grau. */ ?>
    </p>

    <p class="infabout" id="pr2">
	<?php
	echo _pr2name;
	echo _pr2info;
	?>
	<?php
	/*Quin és el nostre compromís?<br>*/
	/*El nostre compromís és oferir accés a tota la teva informació de (nomempresa)
	les 24h/7 dies a la setmana durant els 365 dies de l'any.*/
	?>
 </p>

    <p class="infabout" id="pr3">
        <?php
	echo _pr3name;
	echo _pr3info;
	?>
	<?php
	/*Que es el clouding?<br>*/
	/*Clouding o servei al núvol és un paradigme que permet oferir serveis de computació
	a través d'una xarxa, que usualment és l'internet.*/
	?>
    </p>

    <p class="infabout" id="pr4">
	<?php
	echo _pr4name;
	echo _pr4info;
	?>
	<?php
	/* El nostre servei.<br>
	/*Nosaltres oferim un servei de clouding que consisteix a contractar una part de disc
	dur per poder penjar i descarregar un arxiu des d'on vulguis sempre que tinguis internet.*/
	?>
    </p>

</div>
</main>
