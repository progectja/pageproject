<?php
	$url='http://'.$_SERVER['HTTP_HOST'];
	$homeurl=$url._lang;
	$servicesurl=$homeurl._services.'/';
	$contacturl=$homeurl._contact.'/';
	$abouturl=$homeurl._about.'/';
?>

<?php require_once '/var/www/nicoprj.hopto.org/resources/langs/lang_menu.conf.php'?>

<header>
	<div class="header">
		<a href="http://nicoprj.hopto.org/log/register.php"><?php echo _regist; ?></a>
		<a href="http://nicoprj.hopto.org/log/log.php"><?php echo _log; ?></a>
	</div>
	<h1><?php echo _progect; ?></h1>
	<div>
		<select id="langs" onchange="location = this.value;">
			<option id="ca" value=<?php echo $lang_ca; ?> >ca</option>
			<option id="es" value=<?php echo $lang_es; ?> >es</option>
			<option id="en" value=<?php echo $lang_en; ?> >en</option>
		</select>
	</div>

	<div class="navbar">
		<div class="topnav" id="mySidenav">
			<a id="close" href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
			<a id="home" href=<?php echo $homeurl;?> class=""><?php echo _home; ?></a>
			<a id="services" href=<?php echo $servicesurl;?>  class=""><?php echo _services; ?></a>
			<a id="contact" href=<?php echo $contacturl;?>  class=""><?php echo _contact; ?></a>
			<a id="about" href=<?php echo $abouturl;?> class=""><?php echo _about; ?></a>
		</div>
		<div  class="topnav smallnav">
			<a  href="javascript:void(0);" onclick="openNav()">&#9776;</a>
		</div>
	</div>
</header>

<script>
	$(window).on("resize", function () {
		var docwidth = $(document).width() <= 600;
		if (docwidth) {
			if ($("#mySidenav").hasClass("topnav")){
				$("#mySidenav").toggleClass("topnav sidenav");
			}
			closeNav();
			//$("#option").css("transition","0.3s");
			$("#close").show();
			//mostra
			setTimeout(function() {
				$("#mySidenav").css("transition","0.7s");
			}, 1);
		}
		else{
			$("#mySidenav").css({"width":"100%","transition":"0s"});
			if ($("#mySidenav").hasClass('sidenav')){
				$('#mySidenav').toggleClass('sidenav topnav');
			}
			//$("#option").css("transition","0s");
			$("#close").hide();
			//amaga
		}
	}).resize();

	function openNav() {$("#mySidenav").width("250px");}
	function closeNav() {$("#mySidenav").width("0");}

</script>

<script>
	window.onscroll = function() {myFunction()};

	var navbar = document.getElementById("mySidenav");
	var sticky = navbar.offsetTop;

//	$(window).on("scroll", function () {
	function myFunction() {
		if (window.pageYOffset >= sticky) {
		  navbar.classList.add("sticky");
		  if(window.pageYOffset <=120){navbar.classList.remove("sticky");}
		}
		else {
		  navbar.classList.remove("sticky");
		}
	}
</script>

<script>
	langdoc=document.documentElement.lang;
	url=document.URL.split('/'+langdoc+'/')[0];
	urlang=url+'/'+langdoc;
	//------------------------------
	//
	$('#'+langdoc).attr('selected','');
	//-------------------
</script>
