<main>
	<!--NORMAL------------------------------------------------------------------------------------>
		<h2><?php echo _plan1 ?></h2>
		<div class="wrapper">
			<div class="carousel owl-carousel">
				<div class="card">
					<ul class="price">
						<li class="planname">5GB</li>
						<li class="grey">1,99€/<?php echo _price1 ?></li>
						<li>5GB <?php echo _storage ?></li>
						<li>&nbsp;</li>
						<li>&nbsp;</li>
						<li>&nbsp;</li>
						<li class="grey"><a href="#" class="button">Sign Up</a></li>
					</ul>
				</div>
				<div class="card">
					<ul class="price">
						<li class="planname">10GB</li>
						<li class="grey">3,49€/<?php echo _price1 ?></li>
						<li>10GB <?php echo _storage ?></li>
						<li>&nbsp;</li>
						<li>&nbsp;</li>
						<li>&nbsp;</li>
						<li class="grey"><a href="#"class="button">Sign Up</a></li>
					</ul>
				</div>
				<div class="card">
					<ul class="price">
						<li class="planname">15GB</li>
						<li class="grey">4,99€/<?php echo _price1 ?></li>
						<li>15GB <?php echo _storage ?></li>
						<li>&nbsp;</li>
						<li>&nbsp;</li>
						<li>&nbsp;</li>
						<li class="grey"><a href="#"class="button">Sign Up</a></li>
					</ul>
				</div>
				<div class="card">
					<ul class="price">
						<li class="planname">20GB</li>
						<li class="grey">5,99€/<?php echo _price1 ?></li>
						<li>20GB <?php echo _storage ?></li>
						<li>&nbsp;</li>
						<li>&nbsp;</li>
						<li>&nbsp;</li>
						<li class="grey"><a href="#"class="button">Sign Up</a></li>
					</ul>
				</div>
				<div class="card">
					<ul class="price">
						<li class="planname">50GB</li>
						<li class="grey">11,99€/<?php echo _price1 ?></li>
						<li>50GB <?php echo _storage ?></li>
						<li>+1trash</li>
						<li>&nbsp;</li>
						<li>&nbsp;</li>
						<li class="grey"><a href="#"class="button">Sign Up</a></li>
					</ul>
				</div>
				<div class="card">
					<ul class="price">
						<li class="planname">100GB</li>
						<li class="grey">19,99€/<?php echo _price1 ?></li>
						<li>100GB <?php echo _storage ?></li>
						<li>+1trash</li>
						<li>&nbsp;</li>
						<li>&nbsp;</li>
						<li class="grey"><a href="#"class="button">Sign Up</a></li>
					</ul>
				</div>
				<div class="card">
					<ul class="price">
						<li class="planname">500GB</li>
						<li class="grey">89,99€/<?php echo _price1 ?></li>
						<li>500GB <?php echo _storage ?></li>
						<li>+1trash</li>
						<li>&nbsp;</li>
						<li>&nbsp;</li>
						<li class="grey"><a href="#" class="button">Sign Up</a></li>
					</ul>
				</div>
			</div>
		</div>
	<!-------------------------------------------------------------------------------------------------------->
		<br>
	<!--enterpice--------------------------------------------------------------------------------------------->
		<h2><?php echo _plan2 ?></h2>
		<div class="wrapper">
			<div class="carousel owl-carousel">
				<div class="card ">
					<ul class="price">
						<li class="planname">5GB</li>
						<li class="grey">9,95€/<?php echo _price2 ?></li>
						<li><?php echo _ofert1 ?></li>
						<li>5GB <?php echo _storage ?></li>
						<li><?php echo _trash1 ?></li>
						<li>&nbsp;</li>
						<li class="grey"><a href="#"class="button">Sign Up</a></li>
					</ul>
				</div>
				<div class="card">
					<ul class="price">
						<li class="planname">10GB</li>
						<li class="grey">17,95€/<?php echo _price2 ?></li>
						<li><?php echo _ofert1 ?></li>
						<li>10GB <?php echo _storage ?></li>
						<li><?php echo _trash1 ?></li>
						<li>&nbsp;</li>
						<li class="grey"><a href="#"class="button">Sign Up</a></li>
					</ul>
				</div>
				<div class="card">
					<ul class="price">
						<li class="planname">15GB</li>
						<li class="grey">24,95€/<?php echo _price2 ?></li>
						<li><?php echo _ofert1 ?></li>
						<li>15GB <?php echo _storage ?></li>
						<li><?php echo _trash1 ?></li>
						<li>&nbsp;</li>
						<li class="grey"><a href="#"class="button">Sign Up</a></li>
					</ul>
				</div>
				<div class="card">
					<ul class="price">
						<li class="planname">20GB</li>
						<li class="grey">29,95€/<?php echo _price2 ?></li>
						<li><?php echo _ofert1 ?></li>
						<li>20GB <?php echo _storage ?></li>
						<li><?php echo _trash1 ?></li>
						<li>&nbsp;</li>
						<li class="grey"><a href="#"class="button">Sign Up</a></li>
					</ul>
				</div>
				<div class="card">
					<ul class="price">
						<li class="planname">50GB</li>
						<li class="grey">59,95€/<?php echo _price2 ?></li>
						<li><?php echo _ofert1 ?></li>
						<li>50GB <?php echo _storage ?></li>
						<li><?php echo _trash2 ?></li>
						<li>&nbsp;</li>
						<li class="grey"><a href="#"class="button">Sign Up</a></li>
					</ul>
				</div>
				<div class="card">
					<ul class="price">
						<li class="planname">100GB</li>
						<li class="grey">99,95€/<?php echo _price2 ?></li>
						<li><?php echo _ofert1 ?></li>
						<li>100GB <?php echo _storage ?></li>
						<li><?php echo _trash2 ?></li>
						<li>&nbsp;</li>
						<li class="grey"><a href="#"class="button">Sign Up</a></li>
					</ul>
				</div>
				<div class="card">
					<ul class="price">
						<li class="planname">500GB</li>
						<li class="grey">449,95€/<?php echo _price2 ?></li>
						<li><?php echo _ofert1 ?></li>
						<li>500GB <?php echo _storage ?></li>
						<li><?php echo _trash2 ?></li>
						<li>&nbsp;</li>
						<li class="grey"><a href="#"class="button">Sign Up</a></li>
					</ul>
				</div>
			</div>
		</div>
	<!-------------------------------------------------------------------------------------------------------->
		<br>
	<!--(enterprises plus)------------------------------------------------------------------------------------>
		<h2><?php echo _plan3 ?></h2>
		<div class="wrapper">
			<div class="carousel owl-carousel">
				<div class="card">
					<ul class="price">
						<li class="planname">5GB</li>
						<li class="grey">17,91€/<?php echo _price2 ?></li>
						<li><?php echo _ofert2 ?></li>
						<li><?php echo _trash1 ?></li>
						<li>&nbsp;</li>
						<li>&nbsp;</li>
						<li class="grey"><a href="#"class="button">Sign Up</a></li>
					</ul>
				</div>
				<div class="card" >
					<ul class="price" >
						<li class="planname">10GB</li>
						<li class="grey">31,41€/<?php echo _price2 ?></li>
						<li><?php echo _ofert2 ?></li>
						<li>10GB <?php echo _storage ?></li>
						<li><?php echo _trash1 ?></li>
						<li>&nbsp;</li>
						<li class="grey"><a href="#"class="button">Sign Up</a></li>
					</ul>
				</div>
				<div class="card">
					<ul class="price">
						<li class="planname">15GB</li>
						<li class="grey">44,91€/<?php echo _price2 ?></li>
						<li><?php echo _ofert2 ?></li>
						<li>15GB <?php echo _storage ?></li>
						<li><?php echo _trash1 ?></li>
						<li>&nbsp;</li>
						<li class="grey"><a href="#"class="button">Sign Up</a></li>
					</ul>
				</div>
				<div class="card">
					<ul class="price">
						<li class="planname">20GB</li>
						<li class="grey">53,91€/<?php echo _price2 ?></li>
						<li><?php echo _ofert2 ?></li>
						<li>20GB <?php echo _storage ?></li>
						<li><?php echo _trash1 ?></li>
						<li>&nbsp;</li>
						<li class="grey"><a href="#"class="button">Sign Up</a></li>
					</ul>
				</div>
				<div class="card">
					<ul class="price">
						<li class="planname">50GB</li>
						<li class="grey">107,91€/<?php echo _price2 ?></li>
						<li><?php echo _ofert2 ?></li>
						<li>50GB <?php echo _storage ?></li>
						<li><?php echo _trash2 ?></li>
						<li><?php echo _autgest ?></li>
						<li class="grey"><a href="#"class="button">Sign Up</a></li>
					</ul>
				</div>
				<div class="card">
					<ul class="price">
						<li class="planname">100GB</li>
						<li class="grey">179,91€/<?php echo _price2 ?></li>
						<li><?php echo _ofert2 ?></li>
						<li>100GB <?php echo _storage ?></li>
						<li><?php echo _trash2 ?></li>
						<li><?php echo _autgest ?></li>
						<li class="grey"><a href="#"class="button">Sign Up</a></li>
					</ul>
				</div>
				<div class="card">
					<ul class="price">
						<li class="planname">500GB</li>
						<li class="grey">809,91€/<?php echo _price2 ?></li>
						<li><?php echo _ofert2 ?></li>
						<li>500GB <?php echo _storage ?></li>
						<li><?php echo _trash2 ?></li>
						<li><?php echo _autgest ?></li>
						<li class="grey"><a href="#" class="button">Sign Up</a></li>
					</ul>
				</div>
			</div>
		</div>
		<!-------------------------------------------------------------------------------------------------------->
		<script>
			$(".carousel").owlCarousel({
				margin: 20,
				loop: false,
				autoplay: false,
				autoplayTimeout: 2000,
				autoplayHoverPause: false,
				responsive: {
					0:{items:1,nav: false},
					600:{items:2,nav: false},
					1000:{items:3,nav: false}
					}
				});
		</script>
</main>
