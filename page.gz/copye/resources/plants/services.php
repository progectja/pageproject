	<head>
		<?php include "../../resources/plants/head.php"?>
		<link rel="stylesheet" href="/resources/css/services.css">
		<link rel="stylesheet" href="/resources/css/servicesplus.css">
		<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
		<!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">-->
	</head>
	<body>
		<?php include "../../resources/pages/header.php"?>
		<?php include "../../resources/pages/service.php"?>
		<?php include "../../resources/pages/footer.html"?>
		<script> $('#services').attr('class', 'active'); </script>
	</body>
