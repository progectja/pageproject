	<head>
		<?php include "../../resources/plants/head.php"?>
		<link rel="stylesheet" href="/resources/css/about.css">
	</head>
	<body>
		<?php include "../../resources/pages/header.php"?>
		<?php include "../../resources/pages/about.php"?>
		<?php include "../../resources/pages/footer.html"?>
		<script> $('#about').attr('class', 'active'); </script>
	</body>
