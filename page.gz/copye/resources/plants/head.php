<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>projecte</title>

<link rel="icon" href="/resources/img/favicon.png" type="">
<meta name="description" content="hola">
<link rel="canonical" href="http://nicoprj.hopto.org/">

<link rel="stylesheet" href="/resources/css/header.css">
<link rel="stylesheet" href="/resources/css/common.css">
<link rel="stylesheet" href="/resources/css/footer.css">

<script src="https://code.jquery.com/jquery-3.5.1.js"></script>

<?php require_once '/var/www/nicoprj.hopto.org/resources/langs/'.explode("/",$_SERVER['REQUEST_URI'])[1].'.lang.php';?>
<?php /*aregral a ruta subdinamica (ca== a lang="" del html)*/ ?>
