	<head>
		<?php include "../resources/plants/head.php"?>
		<link rel="stylesheet" href="/resources/css/home.css">
        </head>
	<body>
		<?php include "../resources/pages/header.php"?>
		<?php include "../resources/pages/home.html"?>
		<?php include "../resources/pages/footer.html"?>
		<script> $("#home").attr('class', 'active'); </script>
	</body>

