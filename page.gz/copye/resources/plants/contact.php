	<head>
		<?php include "../../resources/plants/head.php"?>
		<link rel="stylesheet" href="/resources/css/contact.css">
	</head>
	<body>
		<?php include "../../resources/pages/header.php"?>
		<?php include "../../resources/pages/contact.php"?>
		<?php include "../../resources/pages/footer.html"?>
		<script>$("#contact").attr('class', 'active');</script>
	</body>
